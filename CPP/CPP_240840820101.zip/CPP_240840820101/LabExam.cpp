
#include <iostream>
#include <vector>

using namespace std;


//classa Room
class Room{
public:
int roomNumber;
double price;
public:

//to accept room data
void accept(){
    cout<<"Enter Room number: ";
    cin>>roomNumber;
    cout<<"Enter Room price: ";
    cin>>price;
}

//to display rooms
void display(){
    cout<<"Room number: "<<roomNumber<<" | "<<"Room price: "<<price<<endl;
    cout<<endl;

}

//getter to get room number
int getRoomNumber(){
    return roomNumber;
}
};


//class Guest
class Guest{
int guestId;
string name;
//Booked Room list vector to store list of rooms booked by guest
vector <Room*> bookedRoomList;

public:
// to accept guest data
void accept(){
    cout<<"Enter Guest Id: ";
    cin>>guestId;
    cout<<"Enter Guest Name: ";
    cin>>name;
}

//to display guest data
void displayGuest(){
     cout<<"Guest Id: "<<guestId<<endl;
    cout<<"Guest Name: "<<name<<endl;
    cout<<endl;
}

// function to book a room by room id
void bookRoom(vector<Room*> &roomList){
    int roomID;
    //for loop to show rooms
    for(int i=0;i<roomList.size();i++){
        roomList[i]->display();
    }

    cout<<endl;
    cout<<"Enter Room Id to Book Room: ";
    cin>>roomID;

    bool booked=false;
    //for loop to search room with room id annd add to BookedRoomsList
    for(int i=0;i<roomList.size();i++){
        if(roomList[i]->getRoomNumber()==roomID){
        bookedRoomList.push_back(roomList[i]);
        booked=true;
        }
        
    }
    if(booked){
        cout<<"Room Booked"<<endl;

    }else{
        cout<<"Room Not Available"<<endl;
    }

}

//function to display bookedrooms by guest
void displayGuestRooms(){
    for(int i=0;i<bookedRoomList.size();i++){
        bookedRoomList[i]->display();
    }
}

int getGuestId(){
    return guestId;
}


};


void menu(){

    cout<<"____________________________________________________"<<endl;
    cout<<endl;
    cout<<"1. Add new Guest"<<endl;
    cout<<"2. Book Room"<<endl;
    cout<<"3. Display Rooms Booked by Specific Guest"<<endl;
    cout<<"4. Display All Guests and Their Booked Rooms"<<endl;
    cout<<"5. Add Rooms"<<endl;
    cout<<"6. EXIT"<<endl;
    cout<<"____________________________________________________"<<endl;

}

int main(){

    //vector to store guests
    vector<Guest*> guestList;
    //vector to store rooms
    vector<Room*> roomList;

    int choice;


    do{
            menu();
            cout<<"Enter yout choice: ";
            cin>>choice;
        switch(choice){
            //to add guest
            case 1:{
                Guest *g=new Guest();
                g->accept();
                guestList.push_back(g);
                break;
            }
            //to book room
            case 2:{
                int guestId;
                cout<<"Enter Guest Id: ";
                cin>>guestId;
                for(int i=0;i<guestList.size();i++){
                    if(guestList[i]->getGuestId()==guestId){
                        guestList[i]->bookRoom(roomList);
                    }
                    
                }
                break;
            }
            //to Display Rooms Booked by Specific Guest
            case 3:{
                int guestId;
                cout<<"Enter Guest Id: ";
                cin>>guestId;
                for(int i=0;i<guestList.size();i++){
                    if(guestList[i]->getGuestId()==guestId){
                        guestList[i]->displayGuestRooms();
                    }
                    
                }
                break;
            }

            //to Display All Guests and Their Booked Rooms
            case 4:{
                for(int i=0;i<guestList.size();i++){
                guestList[i]->displayGuest();
                guestList[i]->displayGuestRooms();
                

                }

                break;
            }

            //to add rooms
            case 5:{
                Room *g=new Room();
                g->accept();
                roomList.push_back(g);
                break;
            }
            //EXIT
            case 6:{
                cout<<"Thank you for using app"<<endl;
                break;
            }
            

            default:{
                cout<<"Wrong choice"<<endl;
                break;
            }

        }

    }while(choice!=6);

}