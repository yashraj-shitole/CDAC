#include "class.h"


//to accept room data
void Room::accept(){
    cout<<"Enter Room number: ";
    cin>>roomNumber;
    cout<<"Enter Room price: ";
    cin>>price;
}

//to display rooms
void Room::display(){
    cout<<"Room number: "<<roomNumber<<" | "<<"Room price: "<<price<<endl;
    cout<<endl;

}

//getter to get room number
int Room::getRoomNumber(){
    return roomNumber;
}
