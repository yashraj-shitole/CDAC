#ifndef class_h
#define class_h

#include <iostream>
#include <vector>
using namespace std;

class Room{
public:
int roomNumber;
double price;
public:

//to accept room data
void accept();

//to display rooms
void display();

//getter to get room number
int getRoomNumber();
};

#endif